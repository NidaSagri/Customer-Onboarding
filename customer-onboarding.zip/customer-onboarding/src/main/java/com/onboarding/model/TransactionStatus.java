// src/main/java/com/onboarding/model/TransactionStatus.java
package com.onboarding.model;

public enum TransactionStatus {
    PENDING,
    SUCCESSFUL,
    FAILED
}