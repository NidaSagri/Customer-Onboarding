package com.onboarding.model;

public enum KycStatus {
    PENDING,
    VERIFIED,
    REJECTED
}